package com.example.swagger.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.swagger.model.BookSwagger;
import com.example.swagger.service.BookSwaggerService;
@RestController
@RequestMapping("/swaggerbooks")
public class BookSwaggerController {

	@Autowired
	private BookSwaggerService bookSwaggerService;
	
	
	@PostMapping("/add")
	public ResponseEntity<String> addAll(@RequestBody BookSwagger bookSwagger) {
		if (bookSwagger!= null) {
			bookSwaggerService.save(bookSwagger);
			return new ResponseEntity<>("Sccessfully Added",HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("NOT Added",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@PutMapping("/update")
	public ResponseEntity<String> update(@RequestBody BookSwagger bookSwagger){
	BookSwagger book= bookSwaggerService.findById(bookSwagger.getId());
	try {
	if(book.getId()!=null) {
		book.setName(bookSwagger.getName());
		book.setPrice(bookSwagger.getPrice());
		return new ResponseEntity<>("Suceessfully Updated", HttpStatus.OK);
	}
	}catch(Exception e) {

	}
	return new ResponseEntity<>("NOT FOUND",HttpStatus.NOT_FOUND);
	}
	

	@GetMapping("/findall")
	public ResponseEntity<List<BookSwagger>> findAll() {
		List<BookSwagger> bookSwaggers = bookSwaggerService.findAll();
		if (bookSwaggers.size() <= 0) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();

		} else {
			return ResponseEntity.of(Optional.of(bookSwaggers));

		}

	}
	
	@GetMapping("/findbyid")
	public ResponseEntity<String> findById(@RequestParam String id){
		BookSwagger bookSwagger= bookSwaggerService.findById(id);
		if(bookSwagger==null) {
			return new ResponseEntity("NOT FOUND",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(bookSwagger.toString()+"\nSuccessfully found",HttpStatus.FOUND);
		
	}

	
	@DeleteMapping("/deleteall")
	public ResponseEntity<String> deleteAll(){
		bookSwaggerService.deleteAlll();
		return new ResponseEntity<>("Successfully Deleted",HttpStatus.OK);
		
		
	}
	
	@DeleteMapping("/deletebyid")
	public ResponseEntity<String> deleteById(@RequestParam String id){
		BookSwagger bookSwagger= bookSwaggerService.findById(id);
       if(bookSwagger==null) {
	return new ResponseEntity<>("NOT FOUND",HttpStatus.NOT_FOUND);
}
       bookSwaggerService.deleteById(id);
       return new ResponseEntity<>("Deleted", HttpStatus.OK);
	}
	
	
}
