package com.example.swagger.service;

import java.util.List;

import com.example.swagger.model.BookSwagger;

public interface BookSwaggerService {

	List<BookSwagger> findAll();

	void save(BookSwagger bookSwagger);

	BookSwagger findById(String id);

	void deleteAlll();

	void deleteById(String id);

	

}
