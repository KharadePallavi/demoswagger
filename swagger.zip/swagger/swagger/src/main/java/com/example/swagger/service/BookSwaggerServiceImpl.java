package com.example.swagger.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.swagger.dao.BookSwaggerRepository;
import com.example.swagger.model.BookSwagger;

@Service
public class BookSwaggerServiceImpl implements BookSwaggerService {

	@Autowired
	private BookSwaggerRepository bookSwaggerRepository;

	@Override
	public List<BookSwagger> findAll() {
		// TODO Auto-generated method stub
		return bookSwaggerRepository.findAll();
	}

	@Override
	public void save(BookSwagger bookSwagger) {
		// TODO Auto-generated method stub
		bookSwaggerRepository.save(bookSwagger);
	}

	@Override
	public BookSwagger findById(String id) {
		// TODO Auto-generated method stub
		BookSwagger bookSwagger=null;
		try {
	bookSwagger=bookSwaggerRepository.findById(id).get();
	}catch (Exception e) {
		// TODO: handle exception
		
	}
		return bookSwagger;

}

	@Override
	public void deleteAlll() {
		// TODO Auto-generated method stub
		bookSwaggerRepository.deleteAll();
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		bookSwaggerRepository.deleteById(id);
	}

	
}